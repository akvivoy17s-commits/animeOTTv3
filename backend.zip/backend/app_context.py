"""System prompt builder: rules + app data retrieved for THIS question.

In services/openrouter_service.py:
    from app_context import build_system_prompt
    messages = [{"role": "system", "content": build_system_prompt(message)},
                {"role": "user", "content": message}]
"""
try:
    from knowledge.retriever import retrieve
except Exception:  # missing JSON etc. -> static fallback below
    retrieve = None

RULES = """You are the in-app assistant of a Flutter anime streaming app. Help users use the app and answer general anime questions.
- For app questions, use ONLY the APP DATA below (taken from the app's source code). Describe where to tap using page names, 'texts' (real button/label text) and 'reached from'. Never invent buttons or features; if the data doesn't cover it, say you're not sure.
- Page/file names are for you; tell users the screen title or button text, not class names or file paths.
- Parts marked admin-only are visible to admin users only.
- Do not mention or pretend to be any other app.
- Reply in the user's language (Tamil in English letters is fine). Short, friendly. Light formatting only: **bold** and '- ' bullets."""

FALLBACK = """APP DATA: Login/Sign up (email or Google); Home (hero, CONTINUE, Latest Drops, bottom nav); Movies; Series; Search; Saved; video player (fullscreen, playback speed, more videos, retry); Profile (account, settings, about, sign out; admins: Upload Video, Manage Videos)."""


def build_system_prompt(user_message: str) -> str:
    try:
        ctx = retrieve(user_message) if retrieve else FALLBACK
    except Exception:
        ctx = FALLBACK
    return f"{RULES}\n\nAPP DATA:\n{ctx}"
