import 'dart:async';
import 'dart:math' as math;

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../ui/neo.dart';
import 'ai_chat_controller.dart';
import 'ai_chat_panel.dart';

/// Global floating chat button + inline popup panel.
/// Mounted once in MaterialApp.builder, so it sits above every page.
class AiLauncher extends StatefulWidget {
  const AiLauncher({super.key});

  /// Set true once the splash is finished.
  static final ValueNotifier<bool> ready = ValueNotifier(false);

  /// Any page can set true to hide the assistant (e.g. fullscreen player).
  static final ValueNotifier<bool> suppressed = ValueNotifier(false);

  @override
  State<AiLauncher> createState() => _AiLauncherState();
}

class _AiLauncherState extends State<AiLauncher> {
  bool _open = false;
  bool _signedIn = FirebaseAuth.instance.currentUser != null;
  StreamSubscription<User?>? _sub;

  @override
  void initState() {
    super.initState();
    _sub = FirebaseAuth.instance.authStateChanges().listen((u) {
      if (!mounted) return;
      if (u == null) AiChatController.instance.clear(force: true); // no leak
      setState(() {
        _signedIn = u != null;
        if (u == null) _open = false;
      });
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([AiLauncher.ready, AiLauncher.suppressed]),
      builder: (context, _) {
        final mq = MediaQuery.of(context);
        // Hide only on short screens (phone landscape). Desktop/web stays visible.
        final tooShort = mq.size.height < 420;
        final visible = _signedIn &&
            AiLauncher.ready.value &&
            !AiLauncher.suppressed.value &&
            !tooShort;
        if (!visible) return const SizedBox.shrink();

        final wide = mq.size.width >= 600;
        final size = AiChatPanel.sizeFor(mq);
        final double bottom =
            12.0 + math.max(mq.viewInsets.bottom, mq.padding.bottom);

        return Stack(
          children: [
            if (_open)
              Positioned(
                right: wide ? 24 : 12,
                bottom: bottom,
                width: size.width,
                height: size.height,
                child: AiChatPanel(onClose: () => setState(() => _open = false)),
              )
            else
              Positioned(
                right: wide ? 24 : 16,
                // sits above the bottom nav bar
                bottom: 90 + mq.padding.bottom,
                child: _fab(),
              ),
          ],
        );
      },
    );
  }

  Widget _fab() => Tooltip(
        message: 'AI Assistant',
        child: Material(
          color: Neo.surface,
          elevation: 8,
          shape: CircleBorder(side: BorderSide(color: Neo.cyan.withAlpha(128))),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: () => setState(() => _open = true),
            child: const SizedBox(
              width: 52,
              height: 52,
              child: Icon(Icons.auto_awesome, color: Neo.cyan, size: 24),
            ),
          ),
        ),
      );
}
